package com.muthu;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD}) 
@Repeatable(cards.class)
@interface Person{
	String name();
	int age();
}
@Retention(RetentionPolicy.RUNTIME)
@interface cards{
	Person[] value();
}
@Person(name="Ram",age=21)
@Person(name="Krishna",age=26)

@interface MyAnnotation{
	String name="Ram";
	String phonennum="7894642132";
	int age=20;
	long amount=100000;
}

public class Customer {
String name;
String phonenum;
int age;
String accno;
long amount;

public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String accno) {
	super();
	this.accno = accno;
}
public Customer(String name,int age,String phonenum,long amount) {
	super();
	this.name = name;
	this.age = age;
	this.phonenum = phonenum;
	this.amount=amount;
	
}

List<String>mini=new ArrayList<String>();

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAccno() {
	return accno;
}
public void setAccno(String accno) {
	this.accno = accno;
}
public String getPhonenum() {
	return phonenum;
}
public void setPhonenum(String phonenum) {
	this.phonenum = phonenum;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public long getAmount() {
	return amount;
}
public void setAmount(long amount) {
	this.amount = amount;
}

//Code for deposit
public void deposit(List<Customer> a4, int flag) {
	System.out.println("Enter Amount to be Deposited: ");
	Scanner q=new Scanner(System.in);
	long f=q.nextLong();
	amount=a4.get(flag).amount+f;	 
	a4.get(flag).amount=amount;	 
	String s1="Deposited:"+f;	 
	a4.get(flag).mini.add(s1);	
}

//Code for withdraw
public void withdraw(List<Customer> a4, int flag) {
	System.out.println("Enter Amount to be Withdraw: ");
	Scanner q=new Scanner(System.in);
	long f=q.nextLong();
	if(a4.get(flag).amount<f)
	{	 
	System.out.println("Your balance is less..");
	}
	else{
	amount=a4.get(flag).amount-f;	 
	a4.get(flag).amount=amount;	 
	String s1="Withdrawn:"+f;	 
	a4.get(flag).mini.add(s1);	
	}
}
int k=1;

//Code to display the bank balance
public void display(List<Customer> a4, int flag) {
	System.out.println("**********Your Transactions*************");	 
	System.out.println("Name:"+a4.get(flag).name+""+"age:"+a4.get(flag).age+""+"PhoneNo:"+a4.get(flag).phonenum);	 
	System.out.println("Available balance is "+a4.get(flag).amount);	 
	for(int i=a4.get(flag).mini.size()-1;i>=0;i--){	 
	System.out.println(k+"."+a4.get(flag).mini.get(i));
	k++;	 
	if(k==5){	 
	break;
	}	
}
}
}
