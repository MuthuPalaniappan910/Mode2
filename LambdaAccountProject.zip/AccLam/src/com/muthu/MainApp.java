package com.muthu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MainApp {

	public static void main(String[] args) {		
	
	System.out.println("Name is:"+MyAnnotation.name+" Age is:"+MyAnnotation.age+" Number is:"+MyAnnotation.phonennum+" Balance is:"+MyAnnotation.amount);  
	
	Person[] per=MainApp.class.getAnnotationsByType(Person.class);
	for(Person person:per){
		System.out.println(person.name()+" "+person.age());
	}
	//To add the details of the customer with his bank balance
	List<Customer> cust=new ArrayList<Customer>(5);
	Customer cust1=new Customer("Muthu",21,"7897897897",100000);
	Customer cust2=new Customer("Sushanth",21,"4574574574",100000);
	Customer cust3=new Customer("Guru",23,"1291291291",100000);
	Customer cust4=new Customer("Mukund",25,"2892892892",100000);
	Customer cust5=new Customer("Neeraj",27,"6896896896",100000);
	cust.add(cust1);
	cust.add(cust2);
	cust.add(cust3);
	cust.add(cust4);
	cust.add(cust5);
	/*for(int i=0;i<cust.size();i++){
	System.out.println(cust.get(i).name+" "+cust.get(i).age+" "+cust.get(i).phonenum);
	}*/
	
	//To add with the account number
	List<Customer> mylist = new ArrayList<Customer>(5);
	/*System.out.println("Accounts are: ");
	for (int i = 0; i < 5; i++) {
		mylist.add(sc.nextInt());
	}*/
	Customer acc1=new Customer("45675");
	Customer acc2=new Customer("12453");
	Customer acc3=new Customer("47895");
	Customer acc4=new Customer("65784");
	Customer acc5=new Customer("12457");
	mylist.add(acc1);
	mylist.add(acc2);
	mylist.add(acc3);
	mylist.add(acc4);
	mylist.add(acc5);
	System.out.println("Users in Bank :");
	/*for (int i = 0; i < 5; i++) {
		System.out.println(mylist.get(i).accno);
	}*/
	
	//Converting the given number to original bank account number
	List<String> a2 = mylist.stream().map(s -> "SBI" + s.accno).filter(s -> s.length() == 8).collect(Collectors.toList());
	for(int i=0;i<cust.size();i++){
		cust.get(i).accno=a2.get(i);
	}
	
	List<Customer> a1 = cust.stream().filter(s -> (s.age) > 18).collect(Collectors.toList());	
	List<Customer> a3 = a1.stream().filter(s -> (s.phonenum.length()== 10)).collect(Collectors.toList());
	List<Customer> a4 = a3.stream().filter((str -> Character.isUpperCase((str.name).charAt(0))))
			.collect(Collectors.toList());  	
	Collections.sort(a4,(o1 , o2) -> o1.getName().compareTo(o2.getName()));	
	a4.forEach((temp)->{
		System.out.println(temp.name+" "+temp.age+" "+temp.phonenum+" "+temp.accno);
		});	
	
	long count = a4.stream().distinct().count();
	System.out.println("Customers Count are: "+count);
	
	System.out.println("Enter UserName: ");
	int flag=-1,choice=0;
	Scanner sc = new Scanner(System.in);
	String name=sc.next();
	for(int i=0;i<a4.size();i++){
	if(!(name.equals(a4.get(i).name))){		
		flag=-1;
	}
	else{
		flag=i;
		break;
	}
	
	}
	if(flag==-1){
		System.out.println("Invalid User");
	}	
	//System.out.println("Enter Amount: ");
	Customer cus=new Customer();
	do{
		System.out.println("1 : Deposit" );
		System.out.println("2 : Withdraw" );
		System.out.println("3 : Statement" );
		System.out.println("4 : Exit" );
		System.out.println();
		System.out.println("Enter Your Choice: ");	
		choice=sc.nextInt();
		System.out.println();
		switch(choice){
		case 1 :cus.deposit(a4,flag);
		break;
		case 2 :cus.withdraw(a4,flag);
		break;
		case 3:	cus.display(a4,flag); 		
		break;
		case 4:System.out.println("Thanks for using our online services!!!!!!!");
		break;	 
		default:System.out.println("Please make sure your user credentials is correct!!!!");	
		}	
	}while(!(choice==4));
}
}


