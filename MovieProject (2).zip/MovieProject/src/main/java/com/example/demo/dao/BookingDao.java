package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Booking;
import com.example.demo.model.Show;

public interface BookingDao  extends CrudRepository<Booking,Integer>{
/*@Query(select * from showstable where theater_id=t.theater_id where mornShow==mornShow or 
			noonShow==noonShow or
			eveShow==eveShow)
	List<Show> showList(Show show){
		return show;
	}*/
	/*@Query("SELECT * FROM showstable s WHERE s.theater_id =?1 &&( s.mornShow==s.mornShow || s.noonShow==s.noonShow||s.eveShow==s.eveShow)");
			List<Show> listShows(show))*/;
			
			
}