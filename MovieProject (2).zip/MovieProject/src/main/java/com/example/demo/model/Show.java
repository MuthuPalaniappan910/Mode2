package com.example.demo.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="shows")
public class Show {
	private String show_date;
	@Id
	private String theatre_id;
	private String madley_show;
	private String mng_show;
	private String night_show;
	public String getShow_date() {
		return show_date;
	}
	public void setShow_date(String show_date) {
		this.show_date = show_date;
	}
	public String getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(String theatre_id) {
		this.theatre_id = theatre_id;
	}
	public String getMadley_show() {
		return madley_show;
	}
	public void setMadley_show(String madley_show) {
		this.madley_show = madley_show;
	}
	public String getMng_show() {
		return mng_show;
	}
	public void setMng_show(String mng_show) {
		this.mng_show = mng_show;
	}
	public String getNight_show() {
		return night_show;
	}
	public void setNight_show(String night_show) {
		this.night_show = night_show;
	}
}