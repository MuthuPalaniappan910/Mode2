package com.example.demo.handler;

public class MovieNotFoundException {
	private static final long serialVersionUID = 1L;
	public MovieNotFoundException(String exception) {
		super(); 
	}
}
