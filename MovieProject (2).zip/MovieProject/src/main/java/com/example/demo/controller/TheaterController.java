package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Theatre;
import com.example.demo.service.TheaterService;

@RestController
public class TheaterController {
	@Autowired
	TheaterService theaterservice;

	@RequestMapping(value = "/movie/theater/add")
	public String addTheaterDetails(@RequestBody Theatre theater) {
		return theaterservice.addTheaterDetails(theater);

	}

	@GetMapping(value = "/movie/get/shows/{movieName}")
	public List<Theatre> getshow(@PathVariable String movieName) {
		List<Theatre> p = theaterservice.find(movieName);
		return p;

	}

}
