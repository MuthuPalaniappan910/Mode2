package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Theatre;
import com.example.demo.model.User;
import com.example.demo.service.TheaterService;
import com.example.demo.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userservice;

	@RequestMapping(value ="/movie/user/add")
	public String addUserDetails(@RequestBody User user) {
		return userservice.addUserDetails(user);

	}
}
