package com.example.demo.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class BookingDto {
 private String movie_name;
 private String theatre_name;
 private LocalTime show_time;
public String getMovie_name() {
	return movie_name;
}
public void setMovie_name(String movie_name) {
	this.movie_name = movie_name;
}
public String getTheatre_name() {
	return theatre_name;
}
public void setTheatre_name(String theatre_name) {
	this.theatre_name = theatre_name;
}
public LocalTime getShow_time() {
	return show_time;
}
public void setShow_time(LocalTime show_time) {
	this.show_time = show_time;
}
}