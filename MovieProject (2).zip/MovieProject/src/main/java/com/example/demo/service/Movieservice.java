package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.MovieDao;
import com.example.demo.model.Movie;


@Service
public class Movieservice {
	@Autowired 
	 private MovieDao movieDao;
	
	//To add the movie details in the movie table
	public String addMovieDetails(Movie movie) {
		movieDao.save(movie);
		return "movie details saved successfully";
	}
	
	//To show the movie details from the database
	public Iterable<Movie> showMovieDetails() {
	return movieDao.findAll();
	}
}


