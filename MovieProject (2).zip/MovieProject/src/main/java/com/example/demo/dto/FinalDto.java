package com.example.demo.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.example.demo.model.Theatre;

public class FinalDto {
private String theaterName;
private String theaterPlace;
private LocalDate showdate;
private LocalTime showtime;
public LocalDate getShowdate() {
	return showdate;
}
public void setShowdate(LocalDate showdate) {
	this.showdate = showdate;
}
public LocalTime getShowtime() {
	return showtime;
}
public void setShowtime(LocalTime showtime) {
	this.showtime = showtime;
}
private String mornShow;
private String noonShow;
private String eveShow;
public String getTheaterName() {
	return theaterName;
}
public void setTheaterName(String theaterName) {
	this.theaterName = theaterName;
}
public String getTheaterPlace() {
	return theaterPlace;
}
public void setTheaterPlace(String theaterPlace) {
	this.theaterPlace = theaterPlace;
}
public String getMornShow() {
	return mornShow;
}
public void setMornShow(String mornShow) {
	this.mornShow = mornShow;
}
public String getNoonShow() {
	return noonShow;
}
public void setNoonShow(String noonShow) {
	this.noonShow = noonShow;
}
public String getEveShow() {
	return eveShow;
}
public void setEveShow(String eveShow) {
	this.eveShow = eveShow;
}

}
