package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Theatre;

@Repository
public interface TheaterDao extends CrudRepository<Theatre,String> {
	@Query(value="select * from theatre t where t.theatre_id IN (select s.theatre_id from shows s where s.madley_show=?1 or s.mng_show=?1 or s.night_show=?1 or s.show_date=?1)",nativeQuery=true)
	 
	public List<Theatre> find(String movieName);

}
