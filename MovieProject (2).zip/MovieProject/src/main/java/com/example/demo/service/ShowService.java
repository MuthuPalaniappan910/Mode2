package com.example.demo.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.MovieDao;
import com.example.demo.dao.Showdao;
import com.example.demo.dao.TheaterDao;
import com.example.demo.dto.FinalDto;
import com.example.demo.dto.ShowDto;
import com.example.demo.handler.MovieNotFoundException;
import com.example.demo.model.Movie;
import com.example.demo.model.Show;
import com.example.demo.model.Theatre;

@Service
public class ShowService {
	@Autowired
	TheaterDao theaterDao;

	@Autowired
	private Showdao showDao;

	// To add the movie list for each shows for individual theatres
	public String addShowDetails(Show show) {
		showDao.save(show);
		return "show details saved successfully";
	}

	public String checkMovie(ShowDto showdto) throws IOException {
		int flag = 0;
		List<Show> list = (List<Show>) showDao.findAll();
		for (Show show1 : list) {
			if (showdto.getShowSearch().equalsIgnoreCase(show1.getMng_show())
					|| showdto.getShowSearch().equalsIgnoreCase(show1.getMadley_show())
					|| showdto.getShowSearch().equalsIgnoreCase(show1.getNight_show())) {
				flag = 1;
				return "movie exists....";
			}
		}
		if (flag == 0) {
			return "movie not exists...";
		}
		return null;
	}

	
	//To list the Theatres
	public List<Theatre> findDate(LocalDate showdate) {
		List<Theatre> p = showDao.find(showdate);
		return p;
	}
	
	//To set the details of what to be displayed finally to the person
	public List<FinalDto> showList(String movieName) {
		List<Show> listShow = showDao.findByMovieName(movieName);
		Theatre theater1 = new Theatre();
		List<FinalDto> list = new ArrayList();
		for (Show show : listShow) {
			FinalDto finaldto = new FinalDto();
			String theater_id = show.getTheatre_id();
			theater1 = theaterDao.findById(theater_id).orElse(null);
			finaldto.setTheaterName(theater1.getTheatre_name());
			finaldto.setTheaterPlace(theater1.getTheatre_place());
			finaldto.setMornShow(show.getMng_show());
			finaldto.setNoonShow(show.getMadley_show());
			finaldto.setEveShow(show.getNight_show());
			list.add(finaldto);
		}
		return list;

	}

}
