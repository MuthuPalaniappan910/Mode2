package com.example.demo.service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.dao.BookingDao;
import com.example.demo.dao.Showdao;
import com.example.demo.dao.TheaterDao;
import com.example.demo.model.Booking;
import com.example.demo.model.Show;
import com.example.demo.model.Theatre;

@Service
public class BookService {
	int user_id=100;
	@Autowired
	BookingDao bookingDao;
	@Autowired
	TheaterDao theaterDao;
	@Autowired
	Showdao showDao;
	
	//To add the details of the persons who booked their tickets for the movie
	public Booking addBooking(String movie_name, String theaterId, String show_time) {
		Theatre theater = theaterDao.findById(theaterId).orElse(null);
		Show show = showDao.findById(theaterId).orElse(null);
		Booking b = new Booking();
		b.setUser_id("BID"+user_id);
		b.setShow_time(show_time);
		b.setMovie_name(movie_name);
		b.setTheatre_name(theater.getTheatre_name());
		b.setShow_date(show.getShow_date());
		return bookingDao.save(b);
		// return "Successfully entered the Booking details";

	}

}
