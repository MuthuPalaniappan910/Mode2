package com.example.demo.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="booking")
public class Booking {
 private String movie_name;
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private Integer booking_id;
 private String theatre_name;
 private String show_time;
 private String show_date;
 private String user_id;
public String getMovie_name() {
	return movie_name;
}
public void setMovie_name(String movie_name) {
	this.movie_name = movie_name;
}
public Integer getBooking_id() {
	return booking_id;
}
public void setBooking_id(Integer booking_id) {
	this.booking_id = booking_id;
}
public String getTheatre_name() {
	return theatre_name;
}
public void setTheatre_name(String theatre_name) {
	this.theatre_name = theatre_name;
}
public String getShow_time() {
	return show_time;
}
public void setShow_time(String show_time) {
	this.show_time = show_time;
}
public String getShow_date() {
	return show_date;
}
public void setShow_date(String show_date) {
	this.show_date = show_date;
}
public String getUser_id() {
	return user_id;
}
public void setUser_id(String user_id) {
	this.user_id = user_id;
}
}