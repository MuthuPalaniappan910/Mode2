package com.example.demo.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Show;
import com.example.demo.model.Theatre;
@Repository
public interface Showdao  extends CrudRepository<Show,String>{
	@Query(value="select * from shows s where s.theatre_id IN (select t.theatre_id from  theater where t.theatre_name=?1 or t.theatre_place=?1)",nativeQuery=true)
	 
	public List<Theatre> find(LocalDate showdate);
	@Query(value="select * from shows s where s.madley_show=?1 or s.mng_show=?1 or s.night_show=?1",nativeQuery=true)
	 
	public List<Show> findByMovieName(@Param("movieName")String movieName);

	}



