package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BookingDao;
import com.example.demo.dao.TheaterDao;
import com.example.demo.dao.UserDao;
import com.example.demo.dto.BookingDto;

import com.example.demo.model.Booking;
import com.example.demo.model.Theatre;

import com.example.demo.model.User;

@Service
public class UserService {
	@Autowired
	private UserDao userdao;
	
	//To add the user details to the database
	public String addUserDetails(User user) {			
			if(user.getUser_email()==null){
				return "EmailId is mandatory,Please Enter it";			
			}
			else{
			userdao.save(user);
			return "user details saved successfully";
		}
	}
}