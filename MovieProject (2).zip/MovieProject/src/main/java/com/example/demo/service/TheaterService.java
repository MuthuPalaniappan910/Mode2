package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.TheaterDao;
import com.example.demo.model.Theatre;
import com.example.demo.model.User;

@Service
public class TheaterService {

	@Autowired
	private TheaterDao theaterdao;

	// To add the theatre details to the database
	public String addTheaterDetails(Theatre theater) {
		theaterdao.save(theater);
		return "theater details saved successfully";
	}

	// To find the movie whether it is running on a particular theatre
	public List<Theatre> find(String movieName) {
		List<Theatre> p = theaterdao.find(movieName);
		return p;

	}

}
