package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="theatre")
public class Theatre {
	@Id
	 private String theatre_id;
	private String theatre_name;
	private String theatre_place;
	public String getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(String theatre_id) {
		this.theatre_id = theatre_id;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public String getTheatre_place() {
		return theatre_place;
	}
	public void setTheatre_place(String theatre_place) {
		this.theatre_place = theatre_place;
	}
}