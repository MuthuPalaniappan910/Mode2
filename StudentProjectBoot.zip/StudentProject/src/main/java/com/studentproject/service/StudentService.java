package com.studentproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.studentproject.model.College;
import com.studentproject.model.StudentParticulars;
import com.studentproject.model.College;
import com.studentproject.model.StudentParticulars;
import com.studentproject.dao.StudentDao;

@Service
public class StudentService {
	@Autowired
	StudentDao studentDao;

	//To add the student details to the table
	@Transactional
	public void addPerson(StudentParticulars student) {
		studentDao.addPerson(student);
	}
	
	//To list the student details from the table
	@Transactional
	public List<StudentParticulars> listStudent() {
		return this.studentDao.listStudent();
	}

	/*
	 * @Transactional public List<StudentParticulars> listStudent(int page) {
	 * return this.studentDao.listStudent(page); }
	 */
	
	//To list the details using the page number
	@Transactional
	public List<StudentParticulars> listStudent(int pageno, Integer pagesize) {
		return this.studentDao.listStudent(pageno, pagesize);
	}
	
	//To display the place of the student where he studies
	@Transactional
	public College getPlace(StudentParticulars student) {
		return studentDao.getPlace(student);

	}
}
