package com.studentproject.validator;


import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.studentproject.model.StudentParticulars;

public class StudentValidator implements Validator {
	@Override
	public boolean supports(Class<?> paramClass) {
		// TODO Auto-generated method stub
		//return User.class.equals(paramClass);
		return StudentParticulars.class.isAssignableFrom(paramClass);
	}
	
	public void validate(Object obj, Errors errors) {
		// TODO Auto-generated method stub
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentName", "studentName.required","Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentAge", "studentAge.required","Age is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentPhonenumber", "studentPhonenumber.required","PhoneNumber is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentEmail", "studentEmail.required","Email is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentFather", "studentFather.required","Father's Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentMother", "studentMother.required","Mother's Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentPercentage", "studentPercentage.required","Percentage is required");
		
	}

}
