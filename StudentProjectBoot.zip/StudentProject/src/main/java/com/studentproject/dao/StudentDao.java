package com.studentproject.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.studentproject.dao.StudentDao;
import com.studentproject.model.College;
import com.studentproject.model.StudentParticulars;

@Repository
public class StudentDao {
	private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);

	private static final int LIMITITEMSPERPAGE = 6;

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public void addPerson(StudentParticulars student) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student);
	}

	public College getPlace(StudentParticulars student) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql1 = "from Student  clg  where clg.usn = :collegeCode";
		List<College> result = session.createQuery(hql1).setString("collegeCode", student.getUsn()).list();
		if (result.size() != 0) {
			String str = student.getUsn().substring(0, 2);
			System.out.println(str);
			String hql = "from Colleges  clg  where clg.collegeCode = :collegeCode";
			List<College> result1 = session.createQuery(hql).setString("collegeCode", str).list();
			System.out.println(result1.toString());
			return (College) result1.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public List<StudentParticulars> listStudent() {
		Session session = this.sessionFactory.getCurrentSession();
		List<StudentParticulars> personsList = session.createQuery("from StudentParticulars").list();
		for (StudentParticulars p : personsList) {
			logger.info("Person List::" + p);
		}
		return personsList;
	}

	/*
	 * @SuppressWarnings("unchecked") public List<StudentParticulars>
	 * listStudent(int page) { Session session =
	 * this.sessionFactory.getCurrentSession(); List<StudentParticulars>
	 * personsList = session.createQuery("from StudentParticulars").list();
	 * return personsList; }
	 */

	@SuppressWarnings("unchecked")
	public List<StudentParticulars> listStudent(Integer pageno, Integer pagesize) {
		Query query = sessionFactory.getCurrentSession().createQuery("from StudentParticulars");
		query.setMaxResults(2);
		query.setFirstResult(1);
		return (List<StudentParticulars>) query.list();
	}

}
