package com.studentproject.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="studentparticular")

public class StudentParticulars {

	@Id
	String usn;	
	String studentName;	
	String studentAge;
	String studentPhonenumber;	
	String studentEmail;	
	String studentFather;	
	String studentMother;	
	Float studentPercentage;

	public String getUsn() {
		return usn;
	}

	public void setUsn(String usn) {
		this.usn = usn;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(String studentAge) {
		this.studentAge = studentAge;
	}

	public String getStudentPhonenumber() {
		return studentPhonenumber;
	}

	public void setStudentPhonenumber(String studentPhonenumber) {
		this.studentPhonenumber = studentPhonenumber;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentFather() {
		return studentFather;
	}

	public void setStudentFather(String studentFather) {
		this.studentFather = studentFather;
	}

	public String getStudentMother() {
		return studentMother;
	}

	public void setStudentMother(String studentMother) {
		this.studentMother = studentMother;
	}

	public Float getStudentPercentage() {
		return studentPercentage;
	}

	public void setStudentPercentage(Float studentPercentage) {
		this.studentPercentage = studentPercentage;
	}
	
	

}
