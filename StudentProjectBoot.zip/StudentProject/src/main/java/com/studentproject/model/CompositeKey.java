package com.studentproject.model;

public class CompositeKey {

}
