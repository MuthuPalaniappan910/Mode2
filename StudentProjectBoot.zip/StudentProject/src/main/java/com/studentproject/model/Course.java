package com.studentproject.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



import java.io.Serializable;




public class Course implements Serializable
{

/*	*//**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 
	@Id
	Key key;

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}
	
	
}
