package com.studentproject.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="academics")
public class Academics {
	@Id
	String USN;
	String Course;
	Integer Semester;
	public String getUSN() {
		return USN;
	}
	public void setUSN(String uSN) {
		USN = uSN;
	}
	public String getCourse() {
		return Course;
	}
	public void setCourse(String course) {
		Course = course;
	}
	public Integer getSemester() {
		return Semester;
	}
	public void setSemester(Integer semester) {
		Semester = semester;
	}
	
}
