package com.studentproject.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.studentproject.model.College;
import com.studentproject.model.StudentParticulars;
import com.studentproject.service.StudentService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	private StudentService studentService;

	@Autowired
	@Qualifier(value = "studentValidator")
	private Validator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	private Map<String, StudentParticulars> student = null;

	public StudentController() {
		student = new HashMap<String, StudentParticulars>();
	}

	@ModelAttribute("student")
	public StudentParticulars createUserModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new StudentParticulars();
	}

	@RequestMapping(value = "/student/save", method = RequestMethod.GET)
	public String addCustomer(Model model) {
		logger.info("Returning StudentForm.jsp page");
		// model.addAttribute("student", new User());
		return "StudentForm";
	}

	@RequestMapping(value = "/student/save.do", method = RequestMethod.POST)
	public String saveCustomerAction(@ModelAttribute("student") @Validated StudentParticulars student,
			BindingResult bindingResult, Model model) {

		if (bindingResult.hasErrors()) {
			logger.info("Returning StudentForm.jsp page,locale");
			return "StudentForm";
		}
		logger.info("Returning SuccessPage.jsp page");
		model.addAttribute("student", student);
		this.studentService.addPerson(student);
		return "SuccessPage";
	}

	@RequestMapping(value = "/student/display", method = RequestMethod.GET)
	public String listPersons(Model model) {
		model.addAttribute("student", new StudentParticulars());
		model.addAttribute("listStudent", this.studentService.listStudent());
		logger.info("Returning Display.jsp page");
		return "Display";
	}

	/*
	 * @RequestMapping("/student/pagination") public String
	 * listKids(@RequestParam(value = "page", defaultValue="0", required=false)
	 * int page, ModelMap model) { model.addAttribute("listStudent",
	 * studentService.listStudent(page)); logger.info(
	 * "Returning Pagination.jsp page"); return "Pagination"; }
	 */
	@RequestMapping(value = "/student/pagination/{pageno,pagesize}", method = RequestMethod.GET)
	public String getStudentPagination(@RequestParam(defaultValue = "1") Integer pageno,
			@RequestParam(defaultValue = "2") Integer pagesize, ModelMap model) {
		logger.info("Returning Pagination.jsp page");
		model.addAttribute("listStudent", studentService.listStudent(pageno, pagesize));
		return "Pagination";

	}

	@RequestMapping(value = "/student/screen", method = RequestMethod.GET)
	@ResponseBody
	public List<StudentParticulars> listPersons() {
		return studentService.listStudent();
	}

	@RequestMapping(value = "/student/getplace", method = RequestMethod.POST)
	public String getStudentPlace(@ModelAttribute("student") StudentParticulars student, Model model) {
		logger.info("Studet get  place page");
		College college = studentService.getPlace(student);
		// System.out.println(college.toString());
		if (college == null) {
			model.addAttribute("message", "Student does not exist,please enter valid USN");
			return "StudentNotFound";
		} else {
			model.addAttribute("college", college);
			return "place_get";
		}
	}

}
